__version_info__ = ('1', '6', '0')
__version__ = '.'.join(__version_info__)
